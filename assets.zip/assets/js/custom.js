$(document).ready(function () {
    $("input.date-format[type='date']").on("change", function() {
        var dvalue = this.value ? moment(this.value, "YYYY-MM-DD").format("DD/MM/YYYY") : "dd/mm/yyyy";
        this.setAttribute("data-date",dvalue)
    }).trigger("change");    
});